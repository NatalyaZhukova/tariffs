package by.zhukova.tariffs.parser;

public class TariffTypes {

	public static final String WITHOUT_SERVICES = "without-fee-tariff";
	public static final String WITH_SERVICES = "with-fee-tariff";
	public static final String INTERNATIONAL = "international-tariff";
	public static final String CORPORATE = "corporate-tariff";
	
	
	
	
}
